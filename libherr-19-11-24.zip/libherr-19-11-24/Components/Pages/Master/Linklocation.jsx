import React from "react";

export function Linklocation(params) {
    

    return(

        <>
        <h1>Login</h1>
        </>
    )
}